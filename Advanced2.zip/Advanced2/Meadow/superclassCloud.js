"use strict";
/*
Aufgabe: Meadow
Name: Mona Stingl
Matrikel: 267315
Datum: 07.06.21
Quellen: W3School, MDN und Unterrichtsmaterial
*/
var Advanced2;
(function (Advanced2) {
    class SuperclassCloud {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
    }
    Advanced2.SuperclassCloud = SuperclassCloud;
})(Advanced2 || (Advanced2 = {}));
//# sourceMappingURL=superclassCloud.js.map