/*
Aufgabe: Meadow 
Name: Mona Stingl
Matrikel: 267315
Datum: 07.06.21
Quellen: W3School, MDN und Unterrichtsmaterial
*/


namespace Advanced2 {

    export abstract class SuperclassCloud {

        public x: number;
        public y: number;
        public speed: number;

        constructor(_x: number, _y: number) {
            this.x = _x;
            this.y = _y;
        }



    }
}